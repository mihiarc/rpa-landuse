# GeoData Directory
This directory is for caching GeoJSON files used in the map visualizations.

